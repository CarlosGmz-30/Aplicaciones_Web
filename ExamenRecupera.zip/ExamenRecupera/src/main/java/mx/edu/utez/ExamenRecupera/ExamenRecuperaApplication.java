package mx.edu.utez.ExamenRecupera;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenRecuperaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenRecuperaApplication.class, args);
	}

}
