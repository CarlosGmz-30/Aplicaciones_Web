package mx.edu.utez.ExamenRecupera;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenRecuperaApplicationTests {

	@Test
	void contextLoads() {
	}

}
