package mx.edu.utez.Banco.model.entity.User;

public enum Role {
    ADMIN, USER
}
