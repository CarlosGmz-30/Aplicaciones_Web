package mx.edu.utez.Banco.model.entity.user;

public enum Role {
    ADMIN, USER
}
