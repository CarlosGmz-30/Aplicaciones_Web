package mx.edu.utez.Ejemplo4B;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejemplo4BApplicationTests {

	@Test
	void contextLoads() {
	}

}
