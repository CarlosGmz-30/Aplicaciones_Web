package mx.edu.utez.Ejemplo4B;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejemplo4BApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo4BApplication.class, args);
	}

}
